package weartest.com.client.language;

/**
 * Created by alekseyg on 20/12/2015.
 */
public class LanguageManager {
    public static final String NAME = "name";
    public static final String LOG_IN="logIn";
    public static final String HOW_ITS_WORK="howItsWork";
    public static final String LOCKER="locker";
    public static final String WASH="wash";
    public static final String DRY_WASH="dryWash";
    public static final String IRON="iron";
    public static final String NOTES="notes";
    public static final String MORE_CONDITIONER="moreConditioner";
    public static final String WASH_AND_IRON="washAndIroning";
    public static final String DRY_CLINING="dryCleaning";
    public static final String CHOESE_TIME_RETURN_WASH="choeseTimeReturnWash";
    public static final String INVOICE="invoice";








}
