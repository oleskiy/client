package weartest.com.client;

/**
 * Created by alekseyg on 17/02/2016.
 */
public class Invoice {
}
